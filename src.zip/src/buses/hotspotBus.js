import Vue from "vue";
export const hotspotBus = new Vue();