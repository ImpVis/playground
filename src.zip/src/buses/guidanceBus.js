import Vue from 'vue';
const guidanceBus = new Vue({
    data:{ active:false}
});
export default guidanceBus;