import IncrementButton from "./IncrementButton.vue";
export default IncrementButton;
