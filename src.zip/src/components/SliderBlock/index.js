import SliderBlock from "./SliderBlock.vue";
export default SliderBlock; 