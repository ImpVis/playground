import Slider from "./Slider.vue";
import lineTicksComp from './lineTicks.vue';
import NumTicksComp from './numTicks.vue';
import BubbleComp from './bubble.vue';
import inputButton from './inputButton.vue';

export default Slider;
export {lineTicksComp,NumTicksComp,BubbleComp,inputButton};
