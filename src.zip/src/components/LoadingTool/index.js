import LoadingTool from "./LoadingTool.vue";
export default LoadingTool; 