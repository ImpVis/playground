import SectionTitle from "./SectionTitle.vue"
export default SectionTitle;