import Tickbox from "./Tickbox.vue";
export default Tickbox; 