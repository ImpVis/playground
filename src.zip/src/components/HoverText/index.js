import HoverText from "./HoverText.vue";
export default HoverText; 