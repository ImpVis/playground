import LoadingBar from "./LoadingBar.vue";
export default LoadingBar; 