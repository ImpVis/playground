import Tab from "./Tab.vue";
import Tabs from "./Tabs.vue";
export {Tab,Tabs}; 