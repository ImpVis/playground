import SectionHeading from './SectionHeading.vue'
import SidebarSection from './SidebarSection.vue'
import SidebarContent from './SidebarContent.vue'
export {SectionHeading,SidebarSection,SidebarContent};