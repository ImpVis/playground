import PaneNavigator from './PaneNavigator.vue'
import PageIndicator from './PageIndicator.vue'
export {PaneNavigator,PageIndicator};