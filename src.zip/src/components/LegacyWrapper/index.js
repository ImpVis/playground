import LegacyWrapper from './LegacyWrapper';
export default LegacyWrapper;