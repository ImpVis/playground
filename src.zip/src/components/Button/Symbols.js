import Play from "@/assets/media-play.svg"
import Pause from "@/assets/media-pause.svg"
import Stop from "@/assets/media-stop.svg"
import Reset from "@/assets/reload.svg"
import Help from "@/assets/question-mark.svg"
export default {
    Play,
    Pause,
    Stop,
    Reset,
    Help
};