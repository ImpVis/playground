import Hotspot from './Hotspot.vue'
export default Hotspot;