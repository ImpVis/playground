import ToggleHotspot from './ToggleHotspot.vue';
import FixedHotspot from './FixedHotspot.vue';
export {ToggleHotspot,FixedHotspot};