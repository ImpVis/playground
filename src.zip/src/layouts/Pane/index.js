import Pane from './Pane.vue';
export default Pane;