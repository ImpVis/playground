import Window from './Window.vue';
export default Window;