import GuidanceModal from './guidanceModal.vue';
import GuidanceWrapper from './guidanceWrapper.vue';
import GuidanceHome from './guidanceHome.vue';
import GuidanceSystem from './guidanceSystem.vue';

export default GuidanceModal;
export {GuidanceWrapper,GuidanceHome,GuidanceSystem};