import DraggableHotspot from './DraggableHotspot.vue';
export {DraggableHotspot};