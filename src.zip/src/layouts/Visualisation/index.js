import Visualisation from './Visualisation.vue';
export default Visualisation;